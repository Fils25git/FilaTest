# Notes-Generation
this is assistant for teachers of Rwanda who want to generate notes
